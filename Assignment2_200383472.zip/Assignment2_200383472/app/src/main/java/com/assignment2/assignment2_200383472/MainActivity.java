package com.assignment2.assignment2_200383472;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private Button btnOne,btnTwo,btnThree,btnFour,btnFive,btnSix,btnSeven,btnEight,btnNine,btnZero,
            btnAdd,btnMinus,btnDivide,btnMultiply,btnEqual,btnDecimal;
    private Double num1,num2;
    private String currentOperation="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnOne = findViewById(R.id.btnOne);
        btnTwo = findViewById(R.id.btnTwo);
        btnThree = findViewById(R.id.btnThree);
        btnFour = findViewById(R.id.btnFour);
        btnFive = findViewById(R.id.btnFive);
        btnSix = findViewById(R.id.btnSix);
        btnSeven = findViewById(R.id.btnSeven);
        btnEight = findViewById(R.id.btnEight);
        btnNine = findViewById(R.id.btnNine);
        btnZero = findViewById(R.id.btnZero);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnDivide = findViewById(R.id.btnDivide);
        btnAdd = findViewById(R.id.btnPlus);
        btnMinus = findViewById(R.id.btnMinus);
        btnDecimal = findViewById(R.id.btnDecimal);
        btnEqual = findViewById(R.id.btnEqual);
        textView = findViewById(R.id.txtDisplay);


        btnOne.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("1");
                }else{
                    String val = textView.getText().toString();
                    textView.setText(val + "1");
                }
            }
        }));
        btnTwo.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("2");
                }else{
                    String val = textView.getText().toString();
                    textView.setText(val + "2");
                }
            }
        }));
        btnThree.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("3");
                }else{
                    String val = textView.getText().toString();
                    textView.setText(val + "3");
                }
            }
        }));
        btnFour.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("4");
                }else{
                    String val = textView.getText().toString();
                    textView.setText(val + "4");
                }
            }
        }));
        btnFive.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("5");
                }else{
                    String val = textView.getText().toString();
                    textView.setText(val + "5");
                }
            }
        }));
        btnSix.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("6");
                }else{
                    String val = textView.getText().toString();
                    textView.setText(val + "6");
                }
            }
        }));
        btnSeven.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("7");
                }else{
                    String val = textView.getText().toString();
                    textView.setText(val + "7");
                }
            }
        }));
        btnEight.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("8");
                }else{
                    String val = textView.getText().toString();
                    textView.setText(val + "8");
                }
            }
        }));
        btnNine.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("9");
                }else{
                    String val = textView.getText().toString();
                    textView.setText(val + "9");
                }
            }
        }));
        btnZero.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("0");
                }else{
                    String val = textView.getText().toString();
                    textView.setText(val + "0");
                }
            }
        }));
        btnDecimal.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!textView.getText().toString().contains(".")) {
                    String val = textView.getText().toString();
                    textView.setText(val + ".");
                }
            }
        }));
        btnAdd.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textView.getText().length() == 0){
                    textView .setText("Error");
                }else {
                    currentOperation="+";
                    num1 = Double.parseDouble(textView.getText().toString());
                    textView.setText("");
                }
                }
        }));
        btnMinus.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textView.getText().length() == 0){
                    textView .setText("Error");
                }else {
                    currentOperation="-";
                    num1 = Double.parseDouble(textView.getText().toString());
                    textView.setText("");
                }
            }
        }));
        btnMultiply.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textView.getText().length() == 0){
                    textView .setText("Error");
                }else {
                    currentOperation="*";
                    num1 = Double.parseDouble(textView.getText().toString());
                    textView.setText("");
                }
            }
        }));
        btnDivide.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textView.getText().length() == 0){
                    textView .setText("Error");
                }else {
                    currentOperation="/";
                    num1 = Double.parseDouble(textView.getText().toString());
                    textView.setText("");
                }
            }
        }));

        btnEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(num1!=0.0F){
                    num2 = Double.parseDouble(textView.getText().toString());
                    switch (currentOperation){
                        case "+":
                            textView.setText(String.valueOf(num1+num2));
                            break;
                        case "-":
                            textView.setText(String.valueOf(num1-num2));
                            break;
                        case "*":
                            textView.setText(String.valueOf(num1*num2));
                            break;
                        case "/":
                            textView.setText(String.valueOf(num1/num2));
                            break;
                        default:
                            textView.setText("Error");
                            break;
                    }
                }
            }
        });



    }
}
