/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1_200389272;
import java.math.BigDecimal;
import java.util.ArrayList;


/**
 *
 * @author ujjwal bhasin
 */

public class Bank {
	public static enum BranchLocations {BRAMPTON, TORONTO, MARKHAM};
	public String bankName;
        public BranchLocations branchLocation;
        private final String BANKNAMEVALIDATION = "^[a-zA-Z\\s\\-]+$";
        private final String NAMEVALIDATION = "^[a-zA-Z\\s\\-]+$";
        private final String NUMBERVALIDATION = "^[a-zA-Z0-9]+$";
        
        public ArrayList<Account> accounts = new ArrayList<Account>();
    
	public Bank() {}
        
	public Bank(String bankName, String branchLocation) {
            if(bankNameValidation(bankName)){
                this.bankName = bankName;
            }
            else{
                this.bankName = null;
            }
        }
        
	public Bank(String bankName, BranchLocations branchLocation) {
            if(bankNameValidation(bankName)){
                this.bankName = bankName;
            }
            else{
                this.bankName = null;
            }
        }
        
	public String getBankName() {
		return bankName;
	}
	public boolean setBankName(String bankName) {
            if(bankNameValidation(bankName)){
                this.bankName = bankName;
                return true;
            }
		return false;
	}
        
	public boolean setBranchLocation(String branchLocation) {
            if(branchLocationValidation(branchLocation)){
                this.branchLocation = BranchLocations.valueOf(branchLocation.toUpperCase());
            }
		return false;
	}	
	public boolean setBranchLocation(BranchLocations branchLocation) {
            this.branchLocation = branchLocation;
		return true;
	}
        public String getBranchLocation() {
            if(branchLocation != null){
		return branchLocation.name();
            }
            return null;
	}
	public Account getAccountByNumber(String accountNumber) {
            if(isAccountNumberPresent(accountNumber))
		return accounts.stream()
                       .filter(x->accountNumber
                               .equals(x.getAccountNumber()))
                       .findFirst().orElse(new Account());
            return new Account();
	}
	
	public boolean addAccount(Account account) {
               if(!isAccountNumberPresent(account.getAccountNumber())){
                   accounts.add(account);
                   return true;
               }
            return false;
	}
	public boolean addAccount(String accountName, String accountNumber, double accountBalance) {
            if(!isAccountNumberPresent(accountNumber)&& nameValidation(accountName) &&
                    numberValidation(accountNumber)
                     && balanceValidation(accountBalance)){
                accounts.add(new Account(accountName,accountNumber,accountBalance));
                return true;
            }
		return false;
	}
	public Account viewAccount(String accountNumber) {
            if(isAccountNumberPresent(accountNumber))
		return getAccountByNumber(accountNumber);
            return new Account();
	}
	public Account viewAccount(int index) {
            if(index >=0 && accounts.get(index)!=null)
		        return accounts.get(index);
            return new Account();
	}
	public boolean modifyAccount(String accountNumber, String accountName) {
                if(isAccountNumberPresent(accountNumber)){
                    Account account = getAccountByNumber(accountNumber);
                    int index = accounts.indexOf(account);
                    if(nameValidation(accountName))
                        account.setAccountName(accountName);
                    else
                        return false;
                    accounts.add(index, account);
                    return true;
                }
		return false;
	}
	public boolean modifyAccount(String accountNumber, double accountBalance) {
                if(isAccountNumberPresent(accountNumber)){
                   Account account = getAccountByNumber(accountNumber);
                   int index = accounts.indexOf(account);
                   if(balanceValidation(accountBalance))
                     account.setAccountBalance(accountBalance);
                   else
                       return false;
                   accounts.add(index,account);
                   return true;
                }
		return false;
	}
	public boolean modifyAccount(String accountNumber, String accountName, double accountBalance) {
            if(isAccountNumberPresent(accountNumber)){
                   Account account = getAccountByNumber(accountNumber);
                   int index = accounts.indexOf(account);
                   if(nameValidation(accountName))
                        account.setAccountName(accountName);
                   else
                       return false;
                   if(balanceValidation(accountBalance))
                        account.setAccountBalance(accountBalance);
                   else
                       return false;
                   accounts.add(index,account);
                   return true;
              }
		return false;
	}

	public boolean modifyAccount(int index, String accountName) {
            if(index>=0 && accounts.get(index)!=null){
                Account account = accounts.get(index);
                if(nameValidation(accountName))
                    account.setAccountName(accountName);
                else
                    return false;
                accounts.add(index, account);
                return true;
            }
		return false;
	}
	public boolean modifyAccount(int index, double accountBalance) {
            if(index >= 0 && accounts.get(index)!=null){
                Account account = accounts.get(index);
                if(balanceValidation(accountBalance))
                    account.setAccountBalance(accountBalance);
                else
                    return false;
                accounts.add(index, account);
                return true; 
            }
		return false;
	}
	public boolean modifyAccount(int index, String accountName, double accountBalance) {
            if(index >=0 && accounts.get(index)!=null){
               Account account =accounts.get(index);
               if(nameValidation(accountName))
                    account.setAccountName(accountName);
               else
                   return false;
               if(balanceValidation(accountBalance))
                    account.setAccountBalance(accountBalance);
               else
                   return false;
               accounts.add(account);
               return true;
            }
		return false;
	}
	public boolean deleteAccount(String accountNumber) {
            if(isAccountNumberPresent(accountNumber)){
                accounts.remove(getAccountByNumber(accountNumber));
                return true;
            }
		return false;
	}
	public boolean deleteAccount(int index) {
            if(index >=0 && accounts.get(index)!=null){
                accounts.remove(index);
                return true;
            }
            return false;
	}
        
	private boolean bankNameValidation(String bankName){
            return (bankName.matches(BANKNAMEVALIDATION) && bankName.length() >= 5);
        } 
	private boolean branchLocationValidation(String branchValidation){
           for (BranchLocations branchLocation : BranchLocations.values()) {
                if (branchLocation.name().equals(branchValidation.toUpperCase())) {
                    return true;
                }
            }
             return false;
        }
        private boolean nameValidation(String accountName){
            return (accountName.matches(NAMEVALIDATION) && accountName.length() >= 3);
        } 
        
        private boolean numberValidation(String accountNumber){
            return (accountNumber.matches(NUMBERVALIDATION) && accountNumber.length() >= 5);
        }
        private boolean balanceValidation(double accountBalance){
            return accountBalance > 0 && BigDecimal.valueOf(accountBalance).scale()<3;
        }
        
        private boolean isAccountNumberPresent(String accountNumber){
            return accounts.stream()
                       .filter(x->accountNumber
                               .equals(x.getAccountNumber()))
                       .findFirst().isPresent();
        }
}
