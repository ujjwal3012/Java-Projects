/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1_200389272;
import java.math.BigDecimal;
import java.util.Objects;


/**
 *
 * @author ujjwal bhasin
 */

public class Account {
    
    
    private String accountNumber;
    private double accountBalance;
    private String accountName;
    private final String NAMEVALIDATION = "^[a-zA-Z\\s\\-]+$";
    private final String NUMBERVALIDATION = "^[a-zA-Z0-9]+$";



	public Account() {}
	public Account(String accountName, String accountNumber, double accountBalance) {
            
            if(nameValidation(accountName)){
            this.accountName = accountName;
            }
            else{
                this.accountName = null;
            }
            
            if(numberValidation(accountName)){
            this.accountNumber = accountNumber;
            }
            else{
                this.accountNumber = null;
            }
            
            if(balanceValidation(accountBalance)){
            this.accountBalance = accountBalance;
            }
            
	}
	public String getAccountName() {
		return accountName;
                
	}
	public boolean setAccountName(String accountName) {
            if(nameValidation(accountName)){
                this.accountName = accountName;
                return true;
            }
		return false;
	}
        
	public String getAccountNumber() {
		return accountNumber;
	}
	public boolean setAccountNumber(String accountNumber) {
            if(numberValidation(accountNumber)){
                this.accountNumber = accountNumber;
                return true;
            }
		return false;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public boolean setAccountBalance(double value) {
            if(balanceValidation(value)){
            this.accountBalance = value;
            return true;
            }
		return false;
	}
        private boolean nameValidation(String accountName){
            return (accountName.matches(NAMEVALIDATION) && accountName.length() >= 3);
        } 
        
        private boolean numberValidation(String accountNumber){
            return (accountNumber.matches(NUMBERVALIDATION) && accountNumber.length() >= 5);
        }
        private boolean balanceValidation(double accountBalance){
            return (accountBalance > 0 && BigDecimal.valueOf(accountBalance).scale()<3);
        }
        
	@Override
	public boolean equals(Object obj) {
            if(this == obj){
                return true;
            }
            if(obj == null){
                return false;
            }
            if(getClass() != obj.getClass()){
                return false;
            }
            final Account other = (Account) obj;
            if(Double.doubleToLongBits(this.accountBalance) 
                != Double.doubleToLongBits(other.accountBalance)){
            return false;
            }
            if(!Objects.equals(this.accountName, other.accountName)){
		return false;
            }
            if (!Objects.equals(this.accountNumber, other.accountNumber)) {
            return false;
            }
            return true;
	}
	@Override
	public String toString() {
		return "Account{" + "accountName = " + accountName +", "
                        + "accountNumber = " + accountNumber +","
                        + "accountBalance = " + accountBalance + '}';
	}
	
}
